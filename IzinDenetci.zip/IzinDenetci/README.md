# İzin Denetçi

Android uygulaması (Kotlin). İki ekranı var:

1. **İzinler**: Yüklü uygulamalara verilmiş hassas izinleri (mikrofon, kamera, konum, SMS, rehber...) listeler.
   Uygulamanın türünü adından tahmin eder (hava durumu, fener, hesap makinesi, oyun) ve o türe yakışmayan
   izinleri işaretler. Örnek: hava durumu uygulaması mikrofon istiyorsa "Beklenmedik" olarak görünür.
2. **Arka plan**: Son 24 saatte kullanılan uygulamaları, ön planda geçen süreyi, pil kısıtlamasından muaf olanları,
   telefon açılınca başlayanları ve ön plan servisi kullananları gösterir.

Bir uygulamaya dokununca ayrıntı açılır; "Uygulama ayarlarını aç" ile izni oradan kapatabilirsin.

## Kurulum

1. Android Studio (Koala veya daha yeni) ile bu klasörü aç, Gradle senkronizasyonunu bekle.
2. Telefonda geliştirici seçeneklerini ve USB hata ayıklamayı aç, telefonu bağla, Run'a bas.
3. "Arka plan" sekmesinde "Kullanım erişimi ver" butonuna basıp listeden İzin Denetçi'yi aç.

## Sınırlar

- Android, bir uygulamanın o anda arka planda ne yaptığını başka uygulamaya göstermez. Bu yüzden arka plan
  ekranı kesin "şu an çalışıyor" bilgisi değil, son kullanım ve çalışabilme yeteneği bilgisidir.
- Tür tahmini ad/paket adı anahtar kelimelerine dayanır; yanılabilir.
- QUERY_ALL_PACKAGES izni Play Store'da kısıtlıdır; kendi telefonunda kullanmak için sorun değil.
