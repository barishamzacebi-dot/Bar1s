package com.baris.izindenetci

import android.content.Intent
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton

class AppAdapter : RecyclerView.Adapter<AppAdapter.VH>() {

    private var items: List<AppEntry> = emptyList()
    private var mode = 0 // 0 = izinler, 1 = arka plan
    private val expanded = HashSet<String>()

    fun submit(list: List<AppEntry>, newMode: Int) {
        items = list
        mode = newMode
        notifyDataSetChanged()
    }

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val icon: ImageView = v.findViewById(R.id.icon)
        val name: TextView = v.findViewById(R.id.name)
        val summary: TextView = v.findViewById(R.id.summary)
        val badge: TextView = v.findViewById(R.id.badge)
        val details: TextView = v.findViewById(R.id.details)
        val btnSettings: MaterialButton = v.findViewById(R.id.btnSettings)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_app, parent, false)
        return VH(v)
    }

    override fun getItemCount() = items.size

    override fun onBindViewHolder(h: VH, position: Int) {
        val e = items[position]
        val level = if (mode == 0) e.permLevel else e.bgLevel

        h.icon.setImageDrawable(e.icon)
        h.name.text = e.label
        h.summary.text = if (mode == 0) e.permSummary else e.bgSummary
        h.badge.text = level.text
        h.badge.background = GradientDrawable().apply {
            cornerRadius = 40f
            setColor(level.color)
        }

        val open = e.pkg in expanded
        h.details.visibility = if (open) View.VISIBLE else View.GONE
        h.btnSettings.visibility = if (open) View.VISIBLE else View.GONE
        h.details.text = if (mode == 0) e.permDetails else e.bgDetails

        h.itemView.setOnClickListener {
            if (e.pkg in expanded) expanded.remove(e.pkg) else expanded.add(e.pkg)
            notifyItemChanged(h.bindingAdapterPosition)
        }
        h.btnSettings.setOnClickListener {
            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                data = Uri.parse("package:${e.pkg}")
            }
            it.context.startActivity(intent)
        }
    }
}
