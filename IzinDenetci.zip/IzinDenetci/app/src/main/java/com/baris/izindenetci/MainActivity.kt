package com.baris.izindenetci

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton
import com.google.android.material.materialswitch.MaterialSwitch
import com.google.android.material.tabs.TabLayout

class MainActivity : AppCompatActivity() {

    private var all: List<AppEntry> = emptyList()
    private var tab = 0
    private val adapter = AppAdapter()

    private lateinit var info: TextView
    private lateinit var count: TextView
    private lateinit var btnUsage: MaterialButton
    private lateinit var switchSystem: MaterialSwitch
    private lateinit var progress: ProgressBar

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        info = findViewById(R.id.info)
        count = findViewById(R.id.count)
        btnUsage = findViewById(R.id.btnUsage)
        switchSystem = findViewById(R.id.switchSystem)
        progress = findViewById(R.id.progress)

        val recycler = findViewById<RecyclerView>(R.id.recycler)
        recycler.layoutManager = LinearLayoutManager(this)
        recycler.adapter = adapter

        val tabs = findViewById<TabLayout>(R.id.tabs)
        tabs.addTab(tabs.newTab().setText("İzinler"))
        tabs.addTab(tabs.newTab().setText("Arka plan"))
        tabs.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(t: TabLayout.Tab) {
                tab = t.position
                render()
            }
            override fun onTabUnselected(t: TabLayout.Tab) {}
            override fun onTabReselected(t: TabLayout.Tab) {}
        })

        switchSystem.setOnCheckedChangeListener { _, _ -> render() }
        btnUsage.setOnClickListener {
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
        }
    }

    override fun onResume() {
        super.onResume()
        load()
    }

    private fun load() {
        progress.visibility = View.VISIBLE
        Thread {
            val result = Analyzer.scan(this)
            runOnUiThread {
                all = result
                progress.visibility = View.GONE
                render()
            }
        }.start()
    }

    private fun render() {
        val showSystem = switchSystem.isChecked
        val base = all.filter { showSystem || !it.isSystem }

        val list: List<AppEntry>
        if (tab == 0) {
            list = base.sortedWith(
                compareByDescending<AppEntry> { it.permScore }.thenBy { it.label.lowercase() }
            )
            info.text = "Uygulamalara verilmiş hassas izinler. Türü tahmin edilebilen uygulamalarda " +
                "beklenmedik izinler (ör. hava durumu uygulamasında mikrofon) işaretlenir. " +
                "Ayrıntı için uygulamaya dokun."
            btnUsage.visibility = View.GONE
        } else {
            list = base.sortedWith(
                compareByDescending<AppEntry> { it.lastUsed > 0L }
                    .thenByDescending { it.lastUsed }
                    .thenByDescending { it.bgScore }
            )
            info.text = "Android, başka uygulamaların o an arka planda ne yaptığını göstermez. " +
                "Bu ekran son 24 saatteki kullanımı ve arka planda çalışabilme yeteneğini gösterir."
            btnUsage.visibility =
                if (Analyzer.hasUsageAccess(this)) View.GONE else View.VISIBLE
        }

        adapter.submit(list, tab)
        count.text = "${list.size} uygulama"
    }
}
