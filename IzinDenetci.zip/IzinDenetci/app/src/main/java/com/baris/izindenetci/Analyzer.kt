package com.baris.izindenetci

import android.app.AppOpsManager
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.os.Build
import android.os.PowerManager
import android.os.Process
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class Level(val text: String, val color: Int) {
    CLEAN("Temiz", 0xFF2E7D32.toInt()),
    LOW("Düşük", 0xFF689F38.toInt()),
    MEDIUM("Orta", 0xFFF57C00.toInt()),
    HIGH("Yüksek", 0xFFC62828.toInt());

    companion object {
        fun fromScore(s: Int): Level = when {
            s <= 0 -> CLEAN
            s <= 3 -> LOW
            s <= 7 -> MEDIUM
            else -> HIGH
        }
    }
}

data class AppEntry(
    val label: String,
    val pkg: String,
    val icon: Drawable?,
    val isSystem: Boolean,
    val permScore: Int,
    val permLevel: Level,
    val permSummary: String,
    val permDetails: String,
    val bgScore: Int,
    val bgLevel: Level,
    val bgSummary: String,
    val bgDetails: String,
    val lastUsed: Long,
    val fgMs: Long
)

object Analyzer {

    private class PInfo(val label: String, val weight: Int)

    private fun p(n: String) = "android.permission.$n"

    // Hassas izinler, Türkçe adları ve risk ağırlıkları
    private val SENSITIVE: Map<String, PInfo> = mapOf(
        p("RECORD_AUDIO") to PInfo("Mikrofon", 3),
        p("CAMERA") to PInfo("Kamera", 3),
        p("ACCESS_FINE_LOCATION") to PInfo("Hassas konum", 2),
        p("ACCESS_COARSE_LOCATION") to PInfo("Yaklaşık konum", 1),
        p("ACCESS_BACKGROUND_LOCATION") to PInfo("Arka planda konum", 3),
        p("READ_CONTACTS") to PInfo("Rehberi okuma", 2),
        p("WRITE_CONTACTS") to PInfo("Rehberi değiştirme", 2),
        p("READ_SMS") to PInfo("SMS okuma", 4),
        p("RECEIVE_SMS") to PInfo("SMS alma", 4),
        p("SEND_SMS") to PInfo("SMS gönderme", 4),
        p("READ_CALL_LOG") to PInfo("Arama kaydı", 3),
        p("CALL_PHONE") to PInfo("Arama yapma", 2),
        p("READ_PHONE_STATE") to PInfo("Telefon durumu", 1),
        p("READ_CALENDAR") to PInfo("Takvim", 1),
        p("BODY_SENSORS") to PInfo("Vücut sensörleri", 2),
        p("ACTIVITY_RECOGNITION") to PInfo("Fiziksel aktivite", 1),
        p("READ_EXTERNAL_STORAGE") to PInfo("Depolama", 1),
        p("READ_MEDIA_IMAGES") to PInfo("Fotoğraflar", 1),
        p("READ_MEDIA_VIDEO") to PInfo("Videolar", 1),
        p("READ_MEDIA_AUDIO") to PInfo("Ses dosyaları", 1),
        p("SYSTEM_ALERT_WINDOW") to PInfo("Diğer uygulamaların üstünde çizim", 3),
        p("REQUEST_INSTALL_PACKAGES") to PInfo("Uygulama yükleme", 2)
    )

    private enum class Profile(val title: String, val allowed: Set<String>) {
        WEATHER("Hava durumu", setOf(p("ACCESS_FINE_LOCATION"), p("ACCESS_COARSE_LOCATION"))),
        FLASHLIGHT("Fener", setOf(p("CAMERA"))),
        CALCULATOR("Hesap makinesi", emptySet()),
        WALLPAPER("Duvar kağıdı / tema", emptySet()),
        GAME("Oyun", emptySet()),
        GENERIC("Genel", emptySet())
    }

    private fun detectProfile(label: String, pkg: String, ai: ApplicationInfo): Profile {
        val s = "$label $pkg".lowercase(Locale.ROOT)
        return when {
            listOf("weather", "hava", "meteo", "forecast").any { s.contains(it) } -> Profile.WEATHER
            listOf("flashlight", "fener", "torch").any { s.contains(it) } -> Profile.FLASHLIGHT
            listOf("calculator", "hesap mak", "calc").any { s.contains(it) } -> Profile.CALCULATOR
            listOf("wallpaper", "duvar kağıdı", "theme", "tema").any { s.contains(it) } -> Profile.WALLPAPER
            ai.category == ApplicationInfo.CATEGORY_GAME -> Profile.GAME
            else -> Profile.GENERIC
        }
    }

    fun hasUsageAccess(ctx: Context): Boolean {
        val ops = ctx.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = if (Build.VERSION.SDK_INT >= 29) {
            ops.unsafeCheckOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName
            )
        } else {
            @Suppress("DEPRECATION")
            ops.checkOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName
            )
        }
        return mode == AppOpsManager.MODE_ALLOWED
    }

    // paket -> (son kullanım, ön planda geçen süre ms), yalnızca son 24 saat
    private fun loadUsage(ctx: Context): Map<String, Pair<Long, Long>> {
        if (!hasUsageAccess(ctx)) return emptyMap()
        val usm = ctx.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val end = System.currentTimeMillis()
        val start = end - 24L * 3600L * 1000L
        val list = usm.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, start, end) ?: return emptyMap()
        val map = HashMap<String, Pair<Long, Long>>()
        for (s in list) {
            if (s.lastTimeUsed < start) continue
            val old = map[s.packageName]
            val last = maxOf(old?.first ?: 0L, s.lastTimeUsed)
            val fg = (old?.second ?: 0L) + s.totalTimeInForeground
            map[s.packageName] = Pair(last, fg)
        }
        return map
    }

    private fun getPackages(pm: PackageManager): List<PackageInfo> {
        val flags = PackageManager.GET_PERMISSIONS or PackageManager.GET_SERVICES
        return if (Build.VERSION.SDK_INT >= 33) {
            pm.getInstalledPackages(PackageManager.PackageInfoFlags.of(flags.toLong()))
        } else {
            @Suppress("DEPRECATION")
            pm.getInstalledPackages(flags)
        }
    }

    fun scan(ctx: Context): List<AppEntry> {
        val pm = ctx.packageManager
        val power = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
        val usage = loadUsage(ctx)
        val timeFmt = SimpleDateFormat("HH:mm", Locale("tr"))

        return getPackages(pm).mapNotNull { pi ->
            val ai = pi.applicationInfo ?: return@mapNotNull null
            if (pi.packageName == ctx.packageName) return@mapNotNull null

            val label = ai.loadLabel(pm).toString()
            val isSystem = (ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0
            val requested = pi.requestedPermissions ?: emptyArray()
            val flags = pi.requestedPermissionsFlags ?: IntArray(0)

            val granted = ArrayList<String>()
            val deniedButAsked = ArrayList<String>()
            for (i in requested.indices) {
                val perm = requested[i]
                if (perm !in SENSITIVE) continue
                val isGranted = i < flags.size &&
                    (flags[i] and PackageInfo.REQUESTED_PERMISSION_GRANTED) != 0
                if (isGranted) granted.add(perm) else deniedButAsked.add(perm)
            }

            // ---- İzin analizi ----
            val profile = detectProfile(label, pi.packageName, ai)
            val unexpected = granted.filter { it !in profile.allowed }
            val permScore = unexpected.sumOf { SENSITIVE[it]!!.weight }
            val unexpectedNames = unexpected.joinToString(", ") { SENSITIVE[it]!!.label }

            val permSummary = when {
                unexpected.isEmpty() && granted.isEmpty() -> "Verilmiş hassas izin yok"
                unexpected.isEmpty() -> "Yalnızca beklenen izinler (${profile.title})"
                profile != Profile.GENERIC -> "⚠ ${profile.title} uygulaması için beklenmedik: $unexpectedNames"
                else -> "Hassas izinler: $unexpectedNames"
            }
            val permDetails = buildString {
                append("Tür tahmini: ${profile.title}\n")
                append("Verilmiş hassas izinler: ")
                append(if (granted.isEmpty()) "yok" else granted.joinToString(", ") { SENSITIVE[it]!!.label })
                if (profile != Profile.GENERIC && unexpected.isNotEmpty()) {
                    append("\nBu tür bir uygulamanın normalde ihtiyaç duymadığı izinler: $unexpectedNames")
                }
                if (deniedButAsked.isNotEmpty()) {
                    append("\nİstenmiş ama verilmemiş: ")
                    append(deniedButAsked.joinToString(", ") { SENSITIVE[it]!!.label })
                }
                append("\n\nİpucu: Tür tahmini uygulama adı/paket adından yapılır, yanılabilir.")
            }

            // ---- Arka plan analizi ----
            val boot = requested.contains(p("RECEIVE_BOOT_COMPLETED"))
            val fgService = requested.any { it.startsWith(p("FOREGROUND_SERVICE")) }
            val wake = requested.contains(p("WAKE_LOCK"))
            val unrestricted = try {
                power.isIgnoringBatteryOptimizations(pi.packageName)
            } catch (e: Exception) {
                false
            }
            val serviceCount = pi.services?.size ?: 0

            var bgScore = 0
            if (unrestricted) bgScore += 3
            if (boot) bgScore += 1
            if (fgService) bgScore += 1
            if (wake) bgScore += 1
            if (serviceCount >= 5) bgScore += 1

            val u = usage[pi.packageName]
            val lastUsed = u?.first ?: 0L
            val fgMs = u?.second ?: 0L

            val tags = ArrayList<String>()
            if (unrestricted) tags.add("pil kısıtlamasından muaf")
            if (boot) tags.add("telefon açılınca başlar")
            if (fgService) tags.add("ön plan servisi")
            if (wake) tags.add("uyanık tutabilir")

            val usageText = when {
                !hasUsageAccess(ctx) -> "Son kullanım bilinmiyor (kullanım erişimi verilmedi)"
                lastUsed > 0L -> "Son 24 saatte ${fgMs / 60000} dk ön planda · son: ${timeFmt.format(Date(lastUsed))}"
                else -> "Son 24 saatte kullanılmadı"
            }
            val bgSummary = if (tags.isEmpty()) usageText else usageText + "\n" + tags.joinToString(" · ")
            val bgDetails = buildString {
                append("Tanımlı servis sayısı: $serviceCount\n")
                append("Pil kısıtlamasından muaf: ${if (unrestricted) "evet" else "hayır"}\n")
                append("Açılışta başlama izni: ${if (boot) "var" else "yok"}\n")
                append("Ön plan servisi izni: ${if (fgService) "var" else "yok"}\n")
                append("Uyanık tutma (WAKE_LOCK): ${if (wake) "var" else "yok"}")
            }

            AppEntry(
                label = label,
                pkg = pi.packageName,
                icon = try { ai.loadIcon(pm) } catch (e: Exception) { null },
                isSystem = isSystem,
                permScore = permScore,
                permLevel = Level.fromScore(permScore),
                permSummary = permSummary,
                permDetails = permDetails,
                bgScore = bgScore,
                bgLevel = Level.fromScore(bgScore),
                bgSummary = bgSummary,
                bgDetails = bgDetails,
                lastUsed = lastUsed,
                fgMs = fgMs
            )
        }
    }
}
